# 🚀 IRALINK AGENCY — GUIDE DE DÉPLOIEMENT HOSTINGER

## Structure du projet
```
iralink-agency/
├── server.js          ← Serveur Node.js (Express + Nodemailer)
├── package.json       ← Dépendances
├── .env               ← Variables d'environnement (à créer)
├── .env.example       ← Template .env
├── .gitignore
└── public/
    ├── index.html     ← Site web complet
    └── logo.png       ← Logo (remplacer par le vôtre)
```

> Le formulaire de contact utilise **Formspree** (https://formspree.io/f/xjgakllq).
> Le serveur `server.js` avec Nodemailer est disponible en backup si vous préférez
> passer par votre propre email Hostinger — voir section "Email via Nodemailer" ci-dessous.

---

## ÉTAPE 1 — Créer le compte email sur Hostinger

1. Connecte-toi à **hPanel** (panel.hostinger.com)
2. Va dans **Emails → Comptes email**
3. Crée le compte : `consulting@iralink.fr`
4. Note bien le mot de passe — tu en auras besoin

---

## ÉTAPE 2 — Créer le fichier .env

Dans le dossier du projet, crée un fichier `.env` :

```
PORT=3000
SMTP_HOST=smtp.hostinger.com
SMTP_PORT=465
SMTP_USER=consulting@iralink.fr
SMTP_PASS=TON_MOT_DE_PASSE_EMAIL
```

⚠️ Ne partage JAMAIS ce fichier. Il est dans .gitignore.

---

## ÉTAPE 3 — Déployer sur Hostinger Node.js

### Via hPanel (recommandé)

1. hPanel → **Node.js** → **Create application**
2. Remplis :
   - **Node.js version** : 18.x ou 20.x
   - **Application root** : `iralink-agency/`
   - **Application URL** : ton domaine (ex: iralink.fr)
   - **Application startup file** : `server.js`
3. Clique **Create**

4. Upload le projet via **File Manager** ou **FTP** :
   - Compresse le dossier en `.zip`
   - Upload dans le dossier de l'application
   - Extrait le zip

5. Dans hPanel → Node.js → ton app → **Environment variables** :
   - Ajoute `SMTP_PASS` avec ton mot de passe email

6. Dans le terminal SSH ou hPanel :
```bash
cd ~/iralink-agency
npm install
```

7. Clique **Restart** dans hPanel → l'app démarre

### Via SSH

```bash
ssh ton_user@iralink.fr
cd ~/iralink-agency
npm install

# Créer le .env
cp .env.example .env
nano .env   # remplis SMTP_PASS

# Démarrer en production avec PM2
npm install -g pm2
pm2 start server.js --name "iralink"
pm2 save && pm2 startup
```

---

## ÉTAPE 4 — Connecter le domaine & SSL

1. hPanel → **Domains** → vérifie que le domaine pointe vers ton hébergement
2. hPanel → **SSL** → active Let's Encrypt (gratuit)

---

## Basculer vers Nodemailer (optionnel)

Par défaut le formulaire utilise Formspree. Pour utiliser ton propre SMTP Hostinger :

Dans `public/index.html`, remplace le fetch Formspree par :
```js
const res = await fetch('/api/contact', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(Object.fromEntries(new FormData(this)))
});
```

Le endpoint `/api/contact` dans `server.js` est déjà prêt.

---

## EN CAS DE PROBLÈME

| Problème | Solution |
|---|---|
| Email non reçu | Vérifie `SMTP_PASS` dans les variables d'env |
| Site ne s'affiche pas | Vérifie que startup file = `server.js` |
| Port déjà utilisé | Hostinger gère le port, laisse `PORT=3000` |
| Logs d'erreur | hPanel → Node.js → Logs |

---

*Iralink Agency — 2026 — consulting@iralink.fr*
