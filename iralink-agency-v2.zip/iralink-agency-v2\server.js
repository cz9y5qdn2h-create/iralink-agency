require('dotenv').config();
const express = require('express');
const nodemailer = require('nodemailer');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.hostinger.com',
  port: parseInt(process.env.SMTP_PORT) || 465,
  secure: true,
  auth: {
    user: process.env.SMTP_USER || 'consulting@iralink.fr',
    pass: process.env.SMTP_PASS
  }
});

app.post('/api/contact', async (req, res) => {
  const { prenom, nom, email, reseau, sujet, message } = req.body;

  if (!prenom || !email || !message) {
    return res.status(400).json({ success: false, error: 'Champs requis manquants.' });
  }

  const mailToMe = {
    from: '"Iralink Agency" <consulting@iralink.fr>',
    to: 'consulting@iralink.fr',
    replyTo: email,
    subject: `Nouveau contact — ${reseau || 'Non renseigné'} (${sujet || '?'})`,
    html: `<div style="font-family:sans-serif;max-width:600px;background:#080808;color:#F4F2EE;padding:40px;">
      <h2 style="font-family:Georgia,serif;color:#C8A96E;font-weight:300;">Nouveau message reçu</h2>
      <p><strong>Nom :</strong> ${prenom} ${nom || ''}</p>
      <p><strong>Email :</strong> ${email}</p>
      <p><strong>Réseau / Enseigne :</strong> ${reseau || '—'}</p>
      <p><strong>Sujet :</strong> ${sujet || '—'}</p>
      <hr style="border-color:#2A2A2A;margin:20px 0">
      <p><strong>Message :</strong><br>${message}</p>
      <hr style="border-color:#2A2A2A;margin:20px 0">
      <small style="color:#5A5A5A">Iralink Agency — consulting@iralink.fr</small>
    </div>`
  };

  const autoReply = {
    from: '"Théo — Iralink Agency" <consulting@iralink.fr>',
    to: email,
    subject: 'Votre demande a bien été reçue — Iralink Agency',
    html: `<div style="font-family:sans-serif;max-width:600px;background:#080808;color:#F4F2EE;padding:40px;">
      <h1 style="font-family:Georgia,serif;color:#C8A96E;font-weight:300;">Merci ${prenom},</h1>
      <p style="color:#aaa;line-height:1.8;">J'ai bien reçu votre message${reseau ? ' concernant <strong style="color:#F4F2EE">' + reseau + '</strong>' : ''}.<br>Je reviens vers vous dans les <strong style="color:#C8A96E">24h</strong>.</p>
      <p style="color:#aaa;margin-top:20px;">✉️ <span style="color:#C8A96E">consulting@iralink.fr</span></p>
      <p style="color:#5A5A5A;margin-top:40px;font-size:12px;">Théo — Iralink Agency</p>
    </div>`
  };

  try {
    await transporter.sendMail(mailToMe);
    await transporter.sendMail(autoReply);
    res.json({ success: true });
  } catch (err) {
    console.error('Email error:', err);
    res.status(500).json({ success: false, error: 'Erreur envoi email.' });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => console.log(`Iralink Agency running on port ${PORT}`));
